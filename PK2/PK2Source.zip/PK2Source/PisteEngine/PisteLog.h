#ifndef P_LOG
#define P_LOG

/* PROTOTYPES --------------------------------------------------------------------------------*/

void PisteLog_Salli_Kirjoitus();

int  PisteLog_Kirjoita(char *viesti);

#endif