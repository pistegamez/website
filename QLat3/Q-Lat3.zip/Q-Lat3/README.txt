======================================================================
Q-Lat3 by Piste Gamez (2009)
======================================================================
Assembly 09 version
----------------------------------------------------------------------
http://www.pistegamez.net/game_qlat3.html

Description:
======================================================================
Q-Lat3 is a fast paced and colorful arcade type game with a simple, but 
challenging goal: Timer is set to 6 minutes, and your task is to clear 
stages filled with colorful balls by painting all the balls to the same 
color. Painting is done by pushing the colorful balls against each other 
using your player ball. When the balls collide, the slower ball is painted 
with the color of the faster moving ball. From clearing stages you are 
rewarded with bonus points and valuable extra time, so you need to act 
fast. But speed isn't everything - by carefully planning how you smash 
balls together, you can create chain reactions  (a.k.a combos) that earn 
you lots of extra points. But watch out for those dark gray balls - 
you don't get any points from them. And once they start rollling you're 
in trouble!

Fast reflexes, good aiming, quick thinking and sometimes just good luck 
is required to master Q-Lat3. Eventually it is you who sets the goals. 
This game can be as easy or hard as you want it to be ;)

Q-Lat3 is freeware, and can be distributed freely. Janne Kivilahti,
Hugues Jerome, and Antonis Tsagaris own the copyrights for Q-Lat3.

System requirements: 
======================================================================
- Windows XP, Vista
- Monitor that can display at least 1280x720 resolution
- DirectX 9.0.
- Mouse, keyboard and gamepad supported

Credits:
======================================================================
Game design, scripting and sounds effects:
	Janne Kivilahti
Tool & engine programming: 
	Hugues Jerome
Game soundtrack:
	Antonis Tsagaris (http://virb.com/electricsoundcontinuum)
	Janne Kivilahti (Title and song BGM 6)

Software used to create the game:
======================================================================
- MS Visual Studio / tool & engine programming
- Piste Gamez Studio / map & sprite editing and scripting
- Gimp / graphics
- SFRX / sound effects
- MilkyTracker / Title music and song BGM 6
- AnalogX's SayIt / robot speech
- Pyro / particle effects

Game engine uses:
======================================================================
- DirectX
- Angelscript
- Pyro
- Fmod
- Chilkat